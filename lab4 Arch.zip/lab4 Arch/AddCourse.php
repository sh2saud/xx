<?php

include('co.php');
 ?>

<! DOCTYPE html>

<html>
	<head>
	
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="style.css">
		<title>Add Course</title>
		
		

<h1>Add Course Form</h1> 
			</head>
  
			 <nav>
	
		<div class="topnav">
  <a  href="#home">IT Department</a>
  <a href="#home">Home</a>
  <a href="course.php">Course</a>
  <a href="#contact">Add Course</a>
  <a href="#about">Contact US</a>
  <a href="#d">Good Evening</a>
</div>
	 	
		</nav>
	
		<body>
		<section="style=align:center">
		 
			<form action="/action_page.php">
			 <form method = "post" action = "course.php"> 
<div class="rt">
   
		 <p><label>Course Name:</label></p>
		 <input type="text" name="name" placeholder ="Course Name "required >
		 
		 <p><label>Course ID:</label></p>
		 <input type="text" name="ID" placeholder ="Course ID"required >
		 			 
			
		<p><label>Level:</label>
						<p><input type="radio" name="level" value ="1" checked />1</p>
						    <p><input type="radio" name="level" value ="2"/>2
							<p><input name="level" type="radio" value ="3"/>3</p>
							<p><input name="level" type="radio" value ="4"/>4</p>
							<p><input name="level" type="radio" value ="5"/>5</p>
			                <p><input name="level" type="radio" value ="6"/>6</p>
			                <p><input name="level" type="radio" value ="7"/>7</p>
			                <p><input name="level" type="radio" value ="8"/>8</p></p>
			            <a href="course.php"><input type ="submit" value ="Send" name="submit"></a>
				<input type ="reset" value = "Reset"/>
				</div>
				</form>

	<?php
	$conn = mysqli_connect("localhost", "root", "", "lab4");
	if(isset($_POST['submit'])){
   $name = $_POST['name'];
   $id = $_POST['ID'];
   $level= $_POST['level'];

	$insert_query = "insert into course (course_name,course_id,level) values ('$name','$id','$level')";

	if(!mysqli_query($conn,$insert_query))
		 echo "Error:" .$insert_query ."<br>".$conn->error;
	 

}


 ?>
		 		
				
				<footer>
	
	
	<div style="transform: skew(20deg);" class="topnav">
 
	<p style="text-align:right;">@copyright 2018</p>
 
</div>
	</footer>
		 
		</body>
	</html>
	
<?php

include('co.php');
 ?>
 
 <!DOCTYPE>

<html>
     <head>
	    <meta charset ="utf-8">
		<title>lab4</title>
		<link rel="stylesheet" type="text/css" href="style.css"> 
	</head>

	<body>
	
	    <h1>IT Department</h1>
	
			 <nav>
	
		<div class="topnav">
  <a  href="#home">IT Department</a>
  <a href="#home">Home</a>
  <a href="course.php">Course</a>
  <a href="addcourse.php">Add Course</a>
  <a href="#about">Contact US</a>
  <a href="#d">Good Evening</a>
  <a id="time"></a>
</div>
	 	
		</nav>
	 
		  
		 

<form  method="post">
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>ID</strong></th>
<th><strong>courseName</strong></th>
<th><strong>courseID</strong></th>
<th><strong>level</strong></th>
<th><strong>Edit course</strong></th>
<th><strong>Delete course</strong></th>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="SELECT id, course_name, course_id, level FROM course";
$result = mysqli_query($conn,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $row["id"]; ?></td>
<td  align="center"<?php echo  "<td><input type=text name=cousreName value='".$row['cousreName']."'></td>"; ?></td>
<td  align="center"<?php echo  "<td><input type=text name=courdeID value='".$row['courdeID']."'></td>"; ?></td>
<td  align="center"<?php echo  "<td><input type=text name=level value='".$row['level']."'></td>"; ?></td>

<td>
<input type='button' class="edit_button" id="edit_button<?php echo $row['id'];?>" name ="edit" value="edit" onclick="edit_row('<?php echo $row['id'];?>');"></td>
<td><a href="delete.php?id=<?php echo $row["id"]; ?>">Delete</a></td>
</tr>
<?php $count++; } ?>
<?php 
function edit_row($id)
{
    $cousreName = $_POST['course_name'];
    $courdeID =  $_POST['course_id'];
	$level = $_POST['level'];
	$insert_query = "update course set
	  cousre_name= '$cousreName', course_id = '$courdeID', level='$level'
      WHERE id like '$id'";
    if(mysqli_query($conn,$insert_query)){

	echo "<script>alert('done edit course  ')</script>";
				

    echo "<script>window.open('exphp.php','_self')</script>";
					 //return into edit page.
  }
}
?>
</tbody>
</table>
</form>
</div>
		
		<div class="footer">
		<p>&copy;copyright 2018</p>
        </div>
			 
    </body>
	<script type="text/javascript" src="C:\Users\user\Desktop\lab2\script.js"></script>		
</html>



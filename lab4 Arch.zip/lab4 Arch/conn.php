<?php

//shahad Alshahrani 
//43700379
//worksheet 3 
 
$name = $_POST["name"];
$CourseID = $_POST["ID"];
$Level= $_POST["Level"];
$conn = mysqli_connect("localhost", "root", "", "project");
 
 
 
 
 //functoin delete 
function delete(){
	$q = " DELETE from ITdepartment where id='$post_[id]'";

   
  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  }
  $sql = "DELETE * FROM ITdepartment";
  $result = $conn->query($sql); 
	
}

//function add
function add(){
	
 $name = $_POST["name"];
 
$CourseID = $_POST["ID"];
 
$Level= $_POST["Level"];

$q = "INSERT INTO  course (ourse_name ,course_id, level) VALUES ('$name','$id','$level')";

	IF (! mysqli_query($con,$q)) 
           echo "Error:" .$q ."<br>".$con->error;
	else{
		echo"New courses inserted !";
 
	}
	
	 


//function edti 
function edit(){
	
	$q = "update course  from Itdepartment where id='_POST[id]'" ;
	

  // Check connection
  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  }
  $sql = "UPDATE  * FROM ITdepartment";
  $result = $conn->query($sql); 
}

//function get 
function get(){
  
 
 
$query = "SELECT * FROM course WHERE '$id'";
$name = $_POST['name'];
$id = $_POST['ID'];
$level= $_POST['level'];
 
$conn = mysqli_connect("localhost", "root", "", "lab4");
$q = "INSERT INTO  course (ourse_name ,course_id, level) VALUES ('$name','$id','$level')";
	 

  // Check connection
  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 
  $sql = "SELECT  * FROM course";
  $result = $conn->query($sql);
  
  if ($result->num_rows > 0) {
	  
   // output data of each row
   while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row["id"] ."</td><td>" . $row["course_name"]. "</td><td>" . $row["course_id"] . "</td><td>".$row["level"] ."</td>";
   }
   
   
echo "</table>";
  }else { echo "0 results"; }
$conn->close();
 
?>
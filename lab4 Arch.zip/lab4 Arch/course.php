<! DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		  
</head> 
 <nav>
 
	<link rel="stylesheet" type="text/css" href="style.css"/>
		<div class="topnav">
  <a  href="#home">IT Department</a>
  <a href="#home">Home</a>
  <a href="course.html">Course</a>
  <a href="AddCourse.html">Add Course</a>
  <a href="#about">Contact US</a>
  <a href="#d">Good Evening</a>
</div>
	 	 </nav>


<body>
<h2 class="stylesheet, text-align:center">course</h2>
 <table border=2>
 
 <tr>
  <th>ID</th> 
  <th>Course Name</th> 
  <th>Course ID</th> 
  <th>Level</th> 
  <th>Edit Course</th> 
  <th>Delete Course</th> 
 </tr>
  
   
			 
			
 <?php 
  
$conn = mysqli_connect("localhost", "root", "", "lab4");


  // Check connection
  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 
  $sql = "SELECT  * FROM course";
  $result = $conn->query($sql);
  
  if ($result->num_rows > 0) {
	  
   // output data of each row
   while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row["id"] ."</td><td>" . $row["course_name"]. "</td><td>" . $row["course_id"] . "</td><td>".$row["level"] ."</td>";
	?>
	
	 <a href='#'><td><u style="color:blue;">edit course</u></td></a><a href='#'><td><u style="color:blue;">delete course</u></td></tr></a>
	<?php
	
 
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();

 
?>
 
</table>

	<footer>
	
	
	<div style="transform: skew(20deg);" class="topnav">
 
	<p style="text-align:right;">@copyright 2018</p>
 
</div>
	</footer>
	</body>

</html>

 